import pandas as pd

# Read data from CSV file into a DataFrame
csv_df = pd.read_csv('job_data.csv')

# Read data from JSON file into a DataFrame
json_df = pd.read_json('job_data.json')

# Display the first few rows of each DataFrame to inspect the data
print("CSV DataFrame:")
print(csv_df.head())

print("\nJSON DataFrame:")
print(json_df.head())

# Basic data pre-processing tasks
# Handling missing values
csv_df.dropna(inplace=True)  # Drop rows with missing values
json_df.fillna(0, inplace=True)  # Fill missing values with 0

# Handling outliers (example: replacing outliers with median value)
median_value = csv_df['Years of Experience'].median()  # Using 'Years of Experience' as an example
csv_df['Years of Experience'].fillna(median_value, inplace=False)# Fill missing values with median
csv_df.loc[csv_df['Years of Experience'] > 10, 'Years of Experience'] = median_value  # Replace outliers with median

# Manipulating and transforming data
# Filtering
threshold = 3  # Example threshold
filtered_csv_df = csv_df[csv_df['Years of Experience'] > threshold]  # Using 'Years of Experience' as an example

# Sorting
sorted_json_df = json_df.sort_values(by='Salary', ascending=False)  # Sorting by 'Salary' as an example

# Grouping
grouped_csv_df = csv_df.groupby('Job Position').mean()  # Grouping by 'Job Position' as an example

# Display the processed data
print("\nFiltered CSV DataFrame:")
print(filtered_csv_df.head())

print("\nSorted JSON DataFrame:")
print(sorted_json_df.head())

print("\nGrouped CSV DataFrame:")
print(grouped_csv_df.head())
